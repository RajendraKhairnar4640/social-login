from django.urls import path
from .views import index,dashboard_view

urlpatterns = [
    path('index/', index, name='index'),
    path('dashboard/', dashboard_view, name='dashboard'),
]
